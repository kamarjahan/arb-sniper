// 🔐 DEVICE LOCK SYSTEM
(function () {
    'use strict';

    const FIXED_PIN = "6282";
    const STORAGE_KEY = "device_lock_id";

    function getDeviceId() {
        let deviceId = localStorage.getItem(STORAGE_KEY);
        if (!deviceId) {
            deviceId = "DEV-" + Math.random().toString(36).substr(2, 9);
            localStorage.setItem(STORAGE_KEY, deviceId);
        }
        return deviceId;
    }

    function verifyAccess() {
        const savedDevice = localStorage.getItem("authorized_device");
        const currentDevice = getDeviceId();

        if (!savedDevice) {
            const pin = prompt("JACHUI\nEnter Security PIN");
            if (pin !== FIXED_PIN) {
                alert("❌ Wrong PIN! Access Denied.");
                throw new Error("JACHUI: Access Blocked");
            }
            localStorage.setItem("authorized_device", currentDevice);
            alert("✅ Device Registered Successfully");
        } else if (savedDevice !== currentDevice) {
            alert("❌ This device is not authorized!");
            throw new Error("JACHUI: Unauthorized Device");
        }
    }

    verifyAccess();
})();

(function () {
    'use strict';

    // ===== SAFE STORAGE WRAPPER =====
    function getStorage(key, defaultValue) {
        try {
            const val = window.localStorage.getItem(key);
            return val !== null ? val : defaultValue;
        } catch (e) {
            console.warn(`AR Bot: Storage access blocked, using default.`);
            return defaultValue;
        }
    }

    function setStorage(key, value) {
        try {
            window.localStorage.setItem(key, value);
        } catch (e) {
            // Silently ignore if blocked by sandbox
        }
    }

    // ===== STATE MEMORY =====
    let isRunning = getStorage('arbot_isRunning', 'false') === 'true';
    let mode = getStorage('arbot_mode', 'fixed'); // 'fixed' or 'range'
    let targetAmount = getStorage('arbot_targetAmount', '2000');
    let minAmount = getStorage('arbot_minAmount', '1000');
    let maxAmount = getStorage('arbot_maxAmount', '3000');
    let isMinimized = getStorage('arbot_isMinimized', 'false') === 'true';

    let lastDefaultClick = 0;
    let paymentSoundPlayed = false;
    let buying = false; 
    let targetRegex = new RegExp("(?:₹|\\b)" + targetAmount + "(?!\\d)");

    function saveState() {
        setStorage('arbot_isRunning', isRunning);
        setStorage('arbot_mode', mode);
        setStorage('arbot_targetAmount', targetAmount);
        setStorage('arbot_minAmount', minAmount);
        setStorage('arbot_maxAmount', maxAmount);
        setStorage('arbot_isMinimized', isMinimized);
    }

    // ===== SOUND NOTIFICATION =====
    const buySound = new Audio("https://www.image2url.com/r2/default/audio/1787311902363-c14e2447-49c4-4727-8daf-aacdbea83b51.mp3");
    buySound.preload = 'auto';
    const playBuySound = () => {
        buySound.currentTime = 0;
        buySound.play().catch(() => {});
    };

    // ===== FLOATING UI NOTIFICATION =====
    function showFloatingBuy(amount) {
        const f = document.createElement('div');
        Object.assign(f.style, {
            position: 'fixed', top: '50%', left: '50%',
            transform: 'translate(-50%, -50%) scale(1)',
            zIndex: '2147483646',
            background: 'linear-gradient(135deg, #00ff66, #b3ff00)',
            color: '#000', fontFamily: 'monospace', fontWeight: 'bold',
            fontSize: '22px', padding: '14px 28px', borderRadius: '12px',
            boxShadow: '0 0 30px rgba(0,255,102,0.8)',
            pointerEvents: 'none', transition: 'all 0.7s ease-out', opacity: '1'
        });
        f.innerText = '✅ BOUGHT ₹' + amount + '!';
        document.body.appendChild(f);
        requestAnimationFrame(() => requestAnimationFrame(() => {
            f.style.transform = 'translate(-50%, -130%) scale(1.3)';
            f.style.opacity = '0';
        }));
        setTimeout(() => f.remove(), 800);
    }

    // ===== FLOATING MENU =====
    const menu = document.createElement('div');
    menu.id = 'arbot-menu';
    Object.assign(menu.style, {
        position: 'fixed', top: '50px', left: '10px',
        zIndex: '2147483647', userSelect: 'none', touchAction: 'none',
        display: 'flex', flexDirection: 'column',
        background: 'radial-gradient(ellipse at top, #0a1a0f 0%, #0f2e1a 45%, #053b1b 70%, #030d06 100%)',
        border: '2px solid #00ff66', borderRadius: '12px',
        boxShadow: '0 8px 30px rgba(0,0,0,0.6), 0 0 15px rgba(0,255,102,0.4)',
        overflow: 'hidden', fontFamily: 'monospace'
    });
    document.body.appendChild(menu);

    let isDragging = false, dragX = 0, dragY = 0, sx, sy;
    function onDragStart(e) {
        if (e.target.closest('input,button,select')) return;
        const ev = e.type.includes('touch') ? e.touches[0] : e;
        sx = ev.clientX - dragX; sy = ev.clientY - dragY; isDragging = true;
    }
    function onDragMove(e) {
        if (!isDragging) return;
        const ev = e.type.includes('touch') ? e.touches[0] : e;
        dragX = ev.clientX - sx; dragY = ev.clientY - sy;
        menu.style.transform = `translate3d(${dragX}px,${dragY}px,0)`;
    }
    menu.addEventListener('mousedown', onDragStart);
    window.addEventListener('mousemove', onDragMove);
    window.addEventListener('mouseup', () => isDragging = false);
    menu.addEventListener('touchstart', onDragStart, { passive: false });
    window.addEventListener('touchmove', onDragMove, { passive: false });
    window.addEventListener('touchend', () => isDragging = false);

    function renderMenu() {
        if (isMinimized) {
            Object.assign(menu.style, { width: '50px', height: '50px', borderRadius: '50%', padding: '0' });
            menu.innerHTML = `<div id="tBtn" style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;cursor:pointer;font-size:20px;font-weight:900;color:#00ff66;">JI</div>`;
        } else {
            Object.assign(menu.style, { width: '190px', height: 'auto', borderRadius: '12px', padding: '0' });
            menu.innerHTML = `
            <div style="display:flex;align-items:center;padding:8px 12px;border-bottom:1px solid rgba(0,255,102,0.2);">
                <div style="flex:1;display:flex;justify-content:center;margin-left:20px;">
                    <b style="color:#00ff66;font-size:11px;letter-spacing:1px;">JACHUI</b>
                </div>
                <div id="tBtn" style="cursor:pointer;color:#00ff66;font-size:20px;font-weight:bold;width:20px;text-align:right;">−</div>
            </div>
            <div style="padding:10px;">
                <div id="statusDisplay" style="font-size:10px;color:${isRunning ? '#00ff66' : '#ff4444'};text-align:center;margin-bottom:8px;font-weight:bold;background:rgba(0,0,0,0.4);border-radius:4px;padding:4px;">
                    ${isRunning ? '● RUNNING ✅' : '● NOT RUNNING ❌'}
                </div>
                
                <div style="font-size:9px;color:#00ff66;margin-bottom:2px;opacity:0.8;">Mode</div>
                <select id="modeSelect" style="width:100%;padding:6px;margin-bottom:8px;border-radius:6px;border:1px solid #00ff66;background:#0a0a0a;color:#00ff66;box-sizing:border-box;font-weight:bold;font-family:monospace;cursor:pointer;">
                    <option value="fixed" ${mode === 'fixed' ? 'selected' : ''}>Fixed Amount</option>
                    <option value="range" ${mode === 'range' ? 'selected' : ''}>Min & Max Limit</option>
                </select>

                <div id="fixedContainer" style="display: ${mode === 'fixed' ? 'block' : 'none'};">
                    <div style="font-size:9px;color:#00ff66;margin-bottom:2px;opacity:0.8;">Target Amount (₹)</div>
                    <input id="amtIn" type="number" value="${targetAmount}"
                        style="width:100%;padding:7px;margin-bottom:10px;border-radius:6px;border:1px solid #00ff66;background:#0a0a0a;color:#fff;box-sizing:border-box;font-weight:bold;text-align:center;font-family:monospace;">
                </div>

                <div id="rangeContainer" style="display: ${mode === 'range' ? 'block' : 'none'};">
                    <div style="font-size:9px;color:#00ff66;margin-bottom:2px;opacity:0.8;">Min Amount (₹)</div>
                    <input id="minAmtIn" type="number" value="${minAmount}"
                        style="width:100%;padding:6px;margin-bottom:6px;border-radius:6px;border:1px solid #00ff66;background:#0a0a0a;color:#fff;box-sizing:border-box;font-weight:bold;text-align:center;font-family:monospace;">

                    <div style="font-size:9px;color:#00ff66;margin-bottom:2px;opacity:0.8;">Max Amount (₹)</div>
                    <input id="maxAmtIn" type="number" value="${maxAmount}"
                        style="width:100%;padding:6px;margin-bottom:10px;border-radius:6px;border:1px solid #00ff66;background:#0a0a0a;color:#fff;box-sizing:border-box;font-weight:bold;text-align:center;font-family:monospace;">
                </div>
                
                <button id="mainBtn" style="width:100%;padding:10px;border-radius:6px;border:1px solid #00ff66;background:${isRunning ? '#ff4444' : '#00ff66'};color:#000;font-weight:bold;font-size:11px;cursor:pointer;font-family:monospace;">
                    ${isRunning ? 'STOP ⏸️' : 'START ▶️'}
                </button>
            </div>`;
        }
        
        document.getElementById('tBtn').onclick = () => { 
            isMinimized = !isMinimized; 
            saveState();
            renderMenu(); 
        };

        if (!isMinimized) {
            const modeSelect = document.getElementById('modeSelect');
            const amtIn = document.getElementById('amtIn');
            const minAmtIn = document.getElementById('minAmtIn');
            const maxAmtIn = document.getElementById('maxAmtIn');

            modeSelect.onchange = () => {
                mode = modeSelect.value;
                saveState();
                renderMenu();
            };

            const updateInputs = () => {
                if (amtIn) targetAmount = amtIn.value;
                if (minAmtIn) minAmount = minAmtIn.value;
                if (maxAmtIn) maxAmount = maxAmtIn.value;
                targetRegex = new RegExp("(?:₹|\\b)" + targetAmount + "(?!\\d)");
                saveState();
            };

            if (amtIn) amtIn.oninput = updateInputs;
            if (minAmtIn) minAmtIn.oninput = updateInputs;
            if (maxAmtIn) maxAmtIn.oninput = updateInputs;

            document.getElementById('mainBtn').onclick = () => {
                isRunning = !isRunning;
                updateInputs();
                buying = false;
                saveState();
                
                if (isRunning) {
                    startScanning();
                } else {
                    stopScanning();
                }
                renderMenu();
            };
        }
    }

    // ===== NATIVE SIMULATED EVENT TRIGGER =====
    function simulateClick(el) {
        if (!el) return;
        ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'].forEach(type => {
            const ev = new MouseEvent(type, { bubbles: true, cancelable: true, view: window });
            el.dispatchEvent(ev);
        });
    }

    // ===== SCAN CONTROLS =====
    let defaultInterval;
    let buyInterval;

    function startScanning() {
        observer.observe(document.body, { childList: true, subtree: true });
        if (!buyInterval) buyInterval = setInterval(buyOnly, 50);
        if (!defaultInterval) defaultInterval = setInterval(clickDefault, 350);
    }

    function stopScanning() {
        observer.disconnect();
        clearInterval(buyInterval);
        clearInterval(defaultInterval);
        buyInterval = null;
        defaultInterval = null;
    }

    // ===== EXACT TARGETED REFRESH SEQUENCE =====
    function clickDefault() {
        if (!isRunning || buying) return;
        const now = Date.now();
        if (now - lastDefaultClick < 300) return;

        const activePopover = document.querySelector('.van-popover[style*="display"], .van-popover:not([style*="display: none"]), .van-popover__content');
        if (activePopover && activePopover.offsetParent !== null) {
            const actions = Array.from(activePopover.querySelectorAll('.van-popover__action, div, span'));
            const defItem = actions.find(a => (a.innerText || '').trim() === 'Default');
            if (defItem) {
                simulateClick(defItem);
                lastDefaultClick = now;
                return;
            }
        }

        const triggerBtn = document.querySelector('.x-buyList-filter .van-popover__wrapper button, .x-buyList-filter button, .van-popover__wrapper button');
        
        if (triggerBtn) {
            simulateClick(triggerBtn);
            lastDefaultClick = now;

            setTimeout(() => {
                const popover = document.querySelector('.van-popover, .van-popover__content');
                if (popover) {
                    const actionItems = Array.from(popover.querySelectorAll('.van-popover__action, div, span'));
                    const defAction = actionItems.find(a => (a.innerText || '').trim() === 'Default');
                    if (defAction) {
                        simulateClick(defAction);
                    }
                }
            }, 60);
        }
    }

    // ===== SCAN & MATCH OFFERS =====
    function buyOnly() {
        if (!isRunning || buying) return;

        const bodyText = document.body.innerText; 
        if (bodyText.includes('contact customer') || bodyText.includes('Select Method Payment')) {
            if (!paymentSoundPlayed) { playBuySound(); paymentSoundPlayed = true; }
            isRunning = false;
            buying = false;
            saveState();
            stopScanning();
            renderMenu();
            return;
        }
        paymentSoundPlayed = false;

        const items = document.querySelectorAll('.x-buyList-list .item, .van-cell, [class*="item"], tr, .card, div');
        
        for (let i = 0; i < items.length; i++) {
            const item = items[i];
            const amountDisplay = item.querySelector('.amount') || item;
            const itemText = amountDisplay.innerText || item.innerText;

            let matchedAmount = null;

            if (mode === 'fixed') {
                if (targetRegex.test(itemText)) {
                    matchedAmount = targetAmount;
                }
            } else {
                const matches = itemText.match(/(?:₹|\b)(\d+(?:\.\d+)?)\b/g);
                if (matches) {
                    const min = parseFloat(minAmount) || 0;
                    const max = parseFloat(maxAmount) || 0;
                    for (let m of matches) {
                        const num = parseFloat(m.replace(/[^\d.]/g, ''));
                        if (num >= min && num <= max) {
                            matchedAmount = num;
                            break;
                        }
                    }
                }
            }

            if (matchedAmount === null) continue;

            const btn = item.querySelector('.btn.x-btn, .van-button:not(.van-button--disabled), button');
            if (!btn || /finished|completed|已完成/i.test(btn.innerText)) continue;

            buying = true;
            simulateClick(btn);

            let attempts = 0;
            const confirmInterval = setInterval(() => {
                attempts++;
                const confirm = document.querySelector('.van-dialog__confirm, .van-button--danger, .van-dialog button, button.confirm');
                if (confirm) {
                    simulateClick(confirm);
                    playBuySound();
                    showFloatingBuy(matchedAmount);
                    clearInterval(confirmInterval);
                    setTimeout(() => { buying = false; }, 350);
                } else if (attempts > 8) {
                    clearInterval(confirmInterval);
                    buying = false;
                }
            }, 40);

            break;
        }
    }

    // ===== MUTATION OBSERVER =====
    let rafHandle;
    const observer = new MutationObserver(() => {
        if (!rafHandle) {
            rafHandle = requestAnimationFrame(() => {
                buyOnly();
                rafHandle = null;
            });
        }
    });

    renderMenu();
    if (isRunning) {
        startScanning();
    }
})();